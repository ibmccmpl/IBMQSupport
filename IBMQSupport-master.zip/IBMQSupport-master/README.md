# Learning Qiskit: Guided exercises 
Jupyter notebooks containing guided quantum computing exercises with Qiskit.


## Guided exercises (recommended to do in this order)
#### [The quantum version of a NOT gate](./quantum_not_gate_qiskit.ipynb)
This guided exercise is an introduction to creating a single-wire quantum circuit using Qiskit, and to the Pauli-X gate. It also introduces *qubits*, including various ways to represent and visualize them. 

#### [Flipping a coin quantumly](./quantum_coin_flipping.ipynb)
This guided exercise introduces the Hadamard gate, quantum superpositions, probability amplitudes, and measurement probabilities. It also serves as a gentle introduction to Dirac notation.

#### [Rotating around block sphere](./rotating_around_block.ipynb)
This guided exercise introduces the quantum state and its representation in the block sphere. 

#### [Multi-qubit quantum circuits](./multi_qubit_circuits.ipynb)
This guided exercise builds on the previous one by creating circuits with multiple qubits, and examining their quantum state vectors. It also demonstrates how quantum states may be visualized.

#### [Entangling qubits with a CNOT gate](./entangling_qubits.ipynb)
This guided exercise introduces the idea of quantum entanglement, and explores the four Bell states.

#### [Using Aqua for Running Bernstein - Vazirani](./Bernstein-Vazirani.ipynb)
This guided exercise introduces and runs BV algorithm.

#### [Using Aqua for Running Grover](./Grover.ipynb)
This guided exercise introduces and runs Grover algorithm.
