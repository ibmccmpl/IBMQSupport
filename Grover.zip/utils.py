from matplotlib.pyplot import imshow
import numpy as np
from IPython.display import Image, display
# from PIL import Image
# convert a bitsring to the related card
def convert_to_card(val):
    color = int(val[3:], 2)
    sign = int(val[::-1][2:], 2)

    colors = ["clubs", "spades", "hearts", "diamonds"]
    signs = ["8", "7", "10", "9", "Queen", "King", "Ace", "Jack"]

    return signs[sign] + " of " + colors[color]
 
def convert_to_card_image(val):
    color = int(val[3:], 2)
    sign = int(val[::-1][2:], 2)

    colors = ["C", "S", "H", "D"]
    signs = ["8", "7", "10", "9", "Q", "K", "A", "J"]

    return signs[sign]  + colors[color]


def create_express(bitstr):
    V = exprvars('v', len(bitstr))
    index=int(bitstr,2)
    t=2**(len(bitstr))*['0']
    t[index]='1'
    string=''.join(t)
    f = truthtable(V,string )
    result=str(truthtable2expr(f))
    return result

def create_express2(bitstr):
    a=0
    t=[]
    for i in reversed(bitstr):
        if i=='1':
            t.append('v'+str(a))
        elif i=='0':
            t.append('~v'+str(a))
        else:
            print('ce n\'est pas un bitstring en base 2')
            return None
        a=a+1
    string='And('+','.join(t)+')'
    return string
    
# print(Dame)
# pil_im = Image.open('cards/PNG/QH.png', 'r')
def print_image(bitstring):
    name=convert_to_card_image(bitstring)
    pil_im = Image('cards/PNG/'+name+'.png',width=100,height=100)
    display(pil_im)
    
def decimalToBinary(x):
    result=(bin(x)[2:])
    return result

def binaryToDecimal(x):    
    return int(x,2) 
